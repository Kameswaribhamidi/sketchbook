import turtle as t
'''
w - move forward
s - move backward
a - turn left
d - turn right
c - clear screen
'''
def move_front():
    t.forward(10)

def move_back():
    t.back(10)

def turn_left():
    side = t.heading() + 10
    t.setheading(side)
    
def turn_right():
    side = t.heading() - 10
    t.setheading(side)    

def clear_screen():
    t.clear()
    t.penup()
    t.home()
    t.pendown()
        
scr = t.Screen()
scr.listen()
t.pensize(3)
scr.onkey(fun = move_front, key = "w")
scr.onkey(fun = move_back, key = "s")
scr.onkey(fun = turn_left, key = "a")
scr.onkey(fun = turn_right, key = "d")
scr.onkey(fun = clear_screen, key = "c")

scr.exitonclick()